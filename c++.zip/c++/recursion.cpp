#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib> // для использования exit()
#include <vector>
#include <algorithm>
#include <ctime>
using namespace std;

const double INF = 1e9;

int n;   //n- количество узлов
vector<int> p;
vector<vector<int>> a;
vector <bool> used;

void rec(int idx)
{
    if (idx == n-1)
    {
        a.push_back(p);    //добавляем новую перестановку в вектор

        return;
    }
    for (int i = 1; i <= n-1; i++)
    {
        if (used[i]) {
            continue;
        }
        p[idx] = i;
        used[i]=true;             //узел уже использован в перестановке
        rec(idx + 1);             //следующий шаг рекурсии
        used[i]=false;
    } 
}


int main(){

    string file_name = "";
    cin >> file_name;
    file_name +=".txt";
	ifstream in_file(file_name);
	// Если мы не можем открыть файл для чтения его содержимого
	if (!in_file)
	{
		cerr << "Uh oh, Input.txt could not be opened for reading!" << endl;
		exit(1);
	}

    vector <vector <double>> matrix; //матрица смежности
    
    in_file >> n;
    for (int i=0; i<n; i++) {
        vector <double> str;
        for (int j=0; j<n; j++) {
            double node;
            in_file>>node;
            str.push_back(node);
        }
        matrix.push_back(str);
    }

    // for (int i=0; i<n; i++) {
    //     for (int j=0; j<n; j++) {
    //         cout << matrix[i][j]<<" ";
    //     }
    //     cout << endl;
    // }

    p = vector<int>(n-1);
    used = vector<bool>(n,false);

    unsigned int start_time = clock();   //начальное время

    rec(0);

    /*cout<<endl;
    for (int i=0; i<a.size(); i++) {
        for (int j=0; j<a[i].size(); j++) {
            cout << a[i][j]<<" ";
        }
        cout << endl;
    }*/


    double min_weight=INF;
    vector<int> min_way(n-1);

    for (int i=0; i<a.size(); i++) {
        vector<int> path = a[i];
        double weight=0;
        weight+=matrix[0][path[0]];
        for (int j=0; j<path.size()-1; j++) {
            weight+=matrix[path[j]][path[j+1]];
        }
        weight+=matrix[path.back()][0];
        if (weight<=min_weight) {
            min_weight=weight;
            min_way=path;
        }
    }
    min_way.insert(min_way.begin(),0);
    min_way.push_back(0);

//форматирование найденного пути
    vector <int> formatOrder;
    for (int i=0; i<min_way.size(); i++)
        formatOrder.push_back(min_way[i]+1);            //+1, чтобы нумерация узлов начиналась с 1

//НАЧАЛО ВЫВОДА В ФАЙЛ
	ofstream out_file("Output_file1.txt");
 
	// Если мы не можем открыть этот файл для записи данных в него
	if (!out_file)
	{
		// То выводим сообщение об ошибке и выполняем exit()
		cerr << "Uh oh, SomeText.txt could not be opened for writing!" << endl;
		exit(1);
	}

    for (int i=0; i<formatOrder.size(); i++)
        out_file<<formatOrder[i]<<" ";

    cout<<"min_weight: "<<min_weight<<endl;
    cout<<"min_way: ";
    for (int i=0; i<formatOrder.size(); i++)
        cout<<formatOrder[i]<<" ";
    cout<<endl;

    // for (int i=1; i<n-1; i++) {
    //     cout << matrix[i-1][i]

    // }

    unsigned int end_time = clock();   //конечное время
    unsigned int search_time = end_time - start_time;   //искомое время
    cout << "Search_time: " << ((float)search_time) / CLOCKS_PER_SEC  << endl;

    return 0;
}