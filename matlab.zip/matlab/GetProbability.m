function prob = GetProbability(difference, temperature)
prob = exp(-1*difference/temperature);