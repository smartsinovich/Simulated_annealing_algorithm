clear
clc

global matrix;              %весь граф
global n;                   %количество узлов
currentOrder = [];          %текущий путь
nextOrder = [];             %новый возможный путь
shortestDistance = realmax; %длина найденного алгоритмом пути
minimum = realmax;          %минимальная длина, которая попалась во время работы алгоритма

%% Input data
filename = input('Имя файла: ','s');
fileID = fopen(strcat(filename,'.txt'),'r');

n = fscanf(fileID,'%d',1);
matrix = fscanf(fileID,'%f',[n,n]);
xy = fscanf(fileID,'%f',[2,n]);
xy = transpose(xy);
fclose(fileID);

if length(xy)==0
    xy = 10*rand(n,2);
    flag=0;
else 
    flag=1;
end

for i=1:n
    currentOrder(i)=i;
end

%% Annealing
tic

temperature = 1e7;
delteDistance = 0;
coolingRate = 0.9;
absoluteTemperature = 0.00001;

distance = GetTotalDistance(currentOrder);
hAx = gca;
%flag=0;
while(temperature > absoluteTemperature)
    
    % Plot
    if flag==1
        plot(xy(currentOrder,1),xy(currentOrder,2),'b'); 
        %title(sprintf('Total Distance = %1.4f', distance, 'coolingRate = %1.4f', coolingRate));
        title(sprintf('Total Distance = %1.4f, coolingRate = %1.4f', distance, coolingRate));
        drawnow;
    end
    
    nextOrder = GetNextArrangement(currentOrder);
    
    if minimum > GetTotalDistance(nextOrder)
        minimum = GetTotalDistance(nextOrder);
    end
    
    deltaDistance = GetTotalDistance(nextOrder) - distance;
    
    if (deltaDistance < 0) || (deltaDistance>0 && GetProbability(deltaDistance,temperature) > rand)
        currentOrder = nextOrder;
        distance = deltaDistance + distance;
    end
    
    temperature = temperature * coolingRate;
end

shortestDistance = distance;

toc

%% Форматирование маршрута
formatOrder = [];
i=1;
while currentOrder(i)~=1
    i=i+1;
end
for j=i:1:n
    formatOrder = [formatOrder currentOrder(j)];
end
for j=1:1:i-1
    formatOrder = [formatOrder currentOrder(j)];
end
formatOrder = [formatOrder 1]; 

%% Output

fileID = fopen('tsp_output.txt','w');
fprintf(fileID,'%d ',formatOrder);
fclose(fileID);

%% Command Window output

plot(xy(currentOrder,1),xy(currentOrder,2),'b'); 
title(sprintf('Total Distance = %1.4f, coolingRate = %1.5f', distance, coolingRate));

fprintf('Найденный путь: ');
fprintf('%d ',formatOrder);
fprintf('\nshortestDistance: %f\n',shortestDistance);
fprintf('minimum: %f\n',minimum);
