clear 
clear global n p a used
clc

% tsp_ga_turbo;


%% Input data
global n
filename = input('Имя файла: ','s');
fileID = fopen(strcat(filename,'.txt'),'r');

n = fscanf(fileID,'%d',1);
matrix = fscanf(fileID,'%f',[n,n]);

fclose(fileID);
%%
global p a used
p = zeros(1,n-1);
used = zeros(1,n);

tic 

rec(1);

min_weight = inf;
min_way = zeros(n);
for i=1:1:length(a)
    path = a(i,:);
    weight = 0;
    path(1);
    weight = weight + matrix(1, path(1));
    for j=1:1:length(path)-1
        weight = weight + matrix(path(j), path(j+1));
    end
    weight = weight + matrix(path(length(path)), 1);
    if weight<=min_weight
        min_weight = weight;
        min_way = path;
    end
end
min_way = [1 min_way 1];

toc
%% Output

fileID = fopen('recursion_output.txt','w');
fprintf(fileID,'%d ',min_way);
fclose(fileID);

%% Command Window output

fprintf('Найденный путь: ');
fprintf('%d ',min_way);
fprintf('\nshortestDistance: %f\n',min_weight);