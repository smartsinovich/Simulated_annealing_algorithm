function x = GetNextArrangement(x)
global n;
while 1
    pos1 = randi([1 n]);
    pos2 = randi([1 n]);
    if pos1~=pos2
        break;
    end
end
x = swap(x,pos1,pos2);