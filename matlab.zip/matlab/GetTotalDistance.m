function distance = GetTotalDistance(x)
%считает длину пути для конкретного маршрута x
global matrix;
global n;
distance = 0;
for i=2:n
    node1 = x(i-1);
    node2 = x(i);
    distance = distance + matrix(node1,node2);
end
distance = distance + matrix(x(n),x(1));