function x = swap(x,num1,num2)
%эта функция меняет местами два элемента с индексами num1, num2 в векторе х
smth = x(num1);
x(num1) = x(num2);
x(num2) = smth;
