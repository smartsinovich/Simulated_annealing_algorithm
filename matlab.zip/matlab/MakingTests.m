%% Генератор тестов
n = 15;
phi = 0:(2*pi/n):(2*pi-(2*pi/n));
x1 = cos(phi);
x2 = 1.05*cos(phi);
y1 = sin(phi);
y2 = 1.05*sin(phi);
x=[];
for i=1:n
    x = [x;x1(i);x2(i)];
end
y=[];
for i=1:n
    y = [y;y1(i);y2(i)];
end
xy = [x y];
n = n*2;
matrix = zeros(n);
for i=1:1:n
    for j=1:1:n
        if i==j
            matrix(i,j)=0;
        else 
            matrix(i,j)=sqrt((xy(i,1)-xy(j,1))^2 + (xy(i,2)-xy(j,2))^2);
        end
    end
end
matrix;

fileID = fopen('Star30.txt','w');
for i=1:1:n
    fprintf(fileID,'%0.4f ',matrix(i,:));
    fprintf(fileID,'\n');
end
for i=1:1:n
    fprintf(fileID,'%0.4f ',xy(i,:));
    fprintf(fileID,'\n');
end
fclose(fileID);
% plot(xy(:,1),xy(:,2))
% order = [3 4 2 1 5 6 9 7 8 10 15 13 12 14 11 17 16 20 18 16 19 25 30 28 21 23 20 22 29 24 26 27];
% % order = [2 1 3 4 5 6 7 8 9 10 11 12 13 14 15];
% plot(xy(order,1),xy(order,2));
% xy(order(1),:)