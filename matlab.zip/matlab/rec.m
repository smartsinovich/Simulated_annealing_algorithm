function x = rec(idx)
global p a used n
if idx==n
    a = [a; p];
    return;
end
for i=2:1:(n)
   if used(i)==1
       continue;
   end
   p(idx) = i;
   used(i) = 1;
   rec(idx + 1);
   used(i) = 0;
end
x = 1;